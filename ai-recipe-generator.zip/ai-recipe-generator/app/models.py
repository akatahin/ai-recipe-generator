from sqlalchemy import Column, Integer, String, Text
from app.database import Base

class Recipe(Base):
    __tablename__ = 'recipes'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    ingredients = Column(Text, nullable=False)
    instructions = Column(Text, nullable=False)
    prep_time = Column(String(50), nullable=True)  # Preparation time (e.g., "30 minutes")
    difficulty = Column(String(50), nullable=True)  # Difficulty level (e.g., "Easy", "Medium", "Hard")
    serving_size = Column(Integer, nullable=True)  # Number of servings
    image_url = Column(String(255), nullable=True)  # URL for recipe image
    nutritional_info = Column(Text, nullable=True)  # JSON string for nutritional information
