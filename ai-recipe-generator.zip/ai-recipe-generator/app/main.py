from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from app.database import db_session, init_db
from app.models import Recipe
import json
import os

# Initialize Flask App
app = Flask(__name__, static_folder='static')
CORS(app)

# Route to Serve Front-End
@app.route('/')
def serve_index():
    # Serve the index.html from the static folder
    return send_from_directory(app.static_folder, 'index.html')

# Static Files (CSS, JS, etc.)
@app.route('/static/<path:path>')
def serve_static_files(path):
    return send_from_directory(app.static_folder, path)

# API Endpoint to Suggest Recipes
@app.route('/api/suggest', methods=['POST'])
def suggest_recipes():
    data = request.json
    ingredients = data.get('ingredients', '').split(',')
    serving_size = int(data.get('serving_size', 1))

    if not ingredients or not any(ingredients):
        return jsonify({"message": "No ingredients provided."}), 400

    # Fetch matching recipes
    recipes = Recipe.query.filter(
        Recipe.ingredients.like(f"%{','.join(ingredients)}%")
    ).all()

    if not recipes:
        return jsonify({"message": "No recipes found."}), 404

    result = [
        {
            "name": recipe.name,
            "instructions": recipe.instructions,
            "prep_time": recipe.prep_time,  # Include preparation time
            "difficulty": recipe.difficulty,  # Include difficulty level
            "serving_size": recipe.serving_size,  # Include serving size
            "image_url": recipe.image_url,  # Include recipe image URL
            "nutritional_info": {
                key: value * serving_size
                for key, value in json.loads(recipe.nutritional_info).items()
            }
        }
        for recipe in recipes
    ]

    return jsonify({"recipes": result}), 200

# API Endpoint to Populate the Database with Sample Recipes
@app.route('/api/populate', methods=['POST'])
def populate_db():
    try:
        # Load sample recipes from the JSON file
        with open('data/sample_recipes.json') as f:
            recipes = json.load(f)

        for recipe_data in recipes:
            # Check if a recipe with the same name and ingredients already exists
            existing_recipe = Recipe.query.filter_by(
                name=recipe_data['name'],
                ingredients=recipe_data['ingredients']
            ).first()
            if existing_recipe:
                print(f"Skipping duplicate recipe: {recipe_data['name']}")
                continue

            # Add the new recipe
            recipe = Recipe(
                name=recipe_data['name'],
                ingredients=recipe_data['ingredients'],
                instructions=recipe_data['instructions'],
                prep_time=recipe_data.get('prep_time', "Unknown"),
                difficulty=recipe_data.get('difficulty', "Unknown"),
                serving_size=recipe_data.get('serving_size', 1),
                image_url=recipe_data.get('image_url', ""),
                nutritional_info=json.dumps(recipe_data['nutritional_info'])
            )
            db_session.add(recipe)

        db_session.commit()
        return jsonify({"message": "Database populated without duplicates!"}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Cleanup Database Session
@app.teardown_appcontext
def shutdown_session(exception=None):
    db_session.remove()

# Initialize Database and Run the App
if __name__ == "__main__":
    # Ensure the database is initialized
    if not os.path.exists('recipes.db'):
        init_db()

    app.run(debug=True)
