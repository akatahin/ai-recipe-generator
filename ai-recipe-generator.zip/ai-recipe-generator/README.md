  

# AI-Powered Recipe Generator

  

The **AI-Powered Recipe Generator** is a smart cooking assistant that helps you create delicious meals based on the ingredients you already have. This web application uses AI algorithms and a recipe database to provide step-by-step instructions, nutritional details, and suggestions tailored to your needs.



  

---
#### Coded by Nahid
  

## Features

  

### User Features

1.  **Ingredient-Based Recipe Suggestions:**

- Input a list of ingredients (e.g., "chicken, spinach, rice") to get matching recipes.

2.  **Nutritional Information:**

- View detailed nutritional data for each recipe, including calories, protein, carbs, and fat.

  

3.  **Preparation Details:**

- Each recipe includes preparation time, difficulty level, serving size, and an accompanying image.

  

4.  **Interactive Recipe Cards:**

- Hover over cards for animations and zoom effects on recipe images.

  

---

  

## Requirements

  

-  **Python 3.9 or higher**

-  **Flask** for the backend

-  **SQLite** for the database

- Modern browser for the frontend (Chrome, Firefox, or Edge)

  

---

  

## Installation

  

### 1. Clone the Repository

```bash

git clone https://github.com/your-repo/ai-recipe-generator.git

cd ai-recipe-generator

```

  

### 2. Install Dependencies

```bash

pip install -r requirements.txt

```

  

### 3. Set Up the Database

- Ensure that SQLite is installed.

- Initialize the database by running the following:

```bash

python app/main.py

```

  

### 4. Populate the Database

Seed the database with sample recipes using the `/api/populate` endpoint:

```bash

curl -X POST http://127.0.0.1:5000/api/populate

```

  

### 5. Run the Application

- Start the Flask server:

```bash

python app/main.py

```

- Open the `index.html` file in your browser:

```bash

open static/index.html

```

Or navigate to `http://127.0.0.1:5000` in your browser.

  

---

  

## API Endpoints

  

### **1. Suggest Recipes**

-  **URL:**  `/api/suggest`

-  **Method:**  `POST`

-  **Payload:**

```json

{

"ingredients": "chicken, spinach, rice",

"serving_size": 2

}

```

-  **Response:**

```json

{

"recipes": [

{

"name": "Chicken Spinach Rice Bowl",

"instructions": "Cook chicken, add spinach, mix with rice.",

"prep_time": "30 minutes",

"difficulty": "Easy",

"serving_size": 2,

"image_url": "https://example.com/images/chicken_spinach_rice_bowl.jpg",

"nutritional_info": {

"calories": 300,

"protein": 20,

"carbs": 30,

"fat": 8

}

}

]

}

```

  

### **2. Populate the Database**

-  **URL:**  `/api/populate`

-  **Method:**  `POST`

-  **Description:** Adds sample recipes to the database.

-  **Response:**

```json

{

"message": "Database populated without duplicates!"

}

```

  

---

  

## File Structure

```

.

├── app/

│ ├── main.py # Flask app entry point

│ ├── models.py # SQLAlchemy database models

│ ├── database.py # Database configuration and session management

│ ├── static/ # Frontend assets

│ ├── index.html # Main HTML file

│ ├── styles.css # CSS file for styling

│ ├── script.js # JavaScript for client-side logic

├── data/

│ ├── sample_recipes.json # Sample recipes for database population

├── requirements.txt # List of Python dependencies

└── README.md # Documentation

```

  

---

  

## Admin Instructions

  

### 1. Populate the Database

- Use the `/api/populate` endpoint to add sample recipes:

```bash

curl -X POST http://127.0.0.1:5000/api/populate

```

  

### 2. Add More Recipes

- Modify the `data/sample_recipes.json` file with additional recipes in the following format:

```json

{

"name": "Chicken Spinach Rice Bowl",

"ingredients": "chicken, spinach, rice",

"instructions": "Cook chicken, add spinach, mix with rice.",

"nutritional_info": {"calories": 300, "protein": 20, "carbs": 30, "fat": 8},

"prep_time": "30 minutes",

"difficulty": "Easy",

"serving_size": 2,

"image_url": "https://example.com/images/chicken_spinach_rice_bowl.jpg"

}

```

- Repopulate the database by hitting `/api/populate`.

  

---

  

## Frontend Usage

  

1.  **Enter Ingredients:**

- Use the form at the top of the page to input your available ingredients.

  

2.  **View Recipes:**

- Suggested recipes will display below in styled cards, including images and details.

  

3.  **Explore Recipes:**

- Hover over recipe cards for animations and additional details.

  

---

  

## Known Issues

1.  **Duplicate Data:** Ensure the `/api/populate` endpoint checks for duplicates before adding recipes.

2.  **Image Loading:** Use valid URLs for recipe images. Broken links may affect card rendering.

  

---

  

## Future Improvements

1.  **User Authentication:**

- Add user accounts to save and manage personal recipes.

2.  **Voice Input:**

- Enable users to input ingredients using voice commands.

3.  **Smart Integration:**

- Sync with smart appliances or grocery apps for real-time ingredient tracking.

4.  **Dark Mode:**

- Add a toggle for dark mode to improve usability.

  

---

  

## Contributing

1. Fork the repository.

2. Create a new branch: `git checkout -b feature-branch-name`.

3. Commit changes: `git commit -m "Add feature"`.

4. Push to the branch: `git push origin feature-branch-name`.

5. Open a Pull Request.

  

---

  

## License

This project is licensed under the MIT License. See the LICENSE file for details.